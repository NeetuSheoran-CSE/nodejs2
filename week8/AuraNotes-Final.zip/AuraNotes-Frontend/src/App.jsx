import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { DashboardPage } from './pages/DashboardPage';
import { Sparkles } from 'lucide-react';

const MainRouter = () => {
  const { isAuthenticated, isLoading } = useAuth();
  const [authView, setAuthView] = useState('login'); // 'login' | 'register'

  if (isLoading) {
    return (
      <div
        className="bg-ambient-glow"
        style={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '16px',
        }}
      >
        <div
          style={{
            width: '56px',
            height: '56px',
            borderRadius: '16px',
            background: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)',
            color: '#FFFFFF',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: 'var(--shadow-purple)',
            animation: 'pulseGlow 1.8s infinite ease-in-out',
          }}
        >
          <Sparkles size={28} />
        </div>
        <div style={{ fontSize: '0.94rem', fontWeight: 600, color: 'var(--text-muted)' }}>
          Loading your Aura workspace...
        </div>
      </div>
    );
  }

  // Protected route logic: if authenticated, render Dashboard
  if (isAuthenticated) {
    return <DashboardPage />;
  }

  // Otherwise, render Login or Register
  if (authView === 'register') {
    return <RegisterPage onNavigateToLogin={() => setAuthView('login')} />;
  }

  return <LoginPage onNavigateToRegister={() => setAuthView('register')} />;
};

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <MainRouter />
      </AuthProvider>
    </ToastProvider>
  );
}
