import React from 'react';
import { FileText, Star, Clock, Sparkles } from 'lucide-react';

export const StatsOverview = ({ notes = [] }) => {
  const activeNotes = notes.filter((n) => !n.isTrash);
  const totalNotes = activeNotes.length;
  const favoritesCount = activeNotes.filter((n) => n.isFavorite).length;

  // Words count calculation
  const totalWords = activeNotes.reduce((acc, curr) => {
    const text = (curr.content || '').trim();
    if (!text) return acc;
    return acc + text.split(/\s+/).length;
  }, 0);

  // Recently updated note
  const sortedByUpdate = [...activeNotes].sort(
    (a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)
  );
  const mostRecent = sortedByUpdate[0];

  const formatRelativeTime = (isoString) => {
    if (!isoString) return 'None yet';
    const date = new Date(isoString);
    const now = new Date();
    const diffSec = Math.floor((now - date) / 1000);
    if (diffSec < 60) return 'Just now';
    if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
    if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const statCards = [
    {
      title: 'Total Notes',
      value: totalNotes,
      subtext: `${activeNotes.filter((n) => n.category === 'Work').length} work, ${activeNotes.filter((n) => n.category === 'Personal').length} personal`,
      icon: FileText,
      color: '#8B5CF6',
      bg: '#F3EEFF',
    },
    {
      title: 'Starred Favorites',
      value: favoritesCount,
      subtext: totalNotes > 0 ? `${Math.round((favoritesCount / totalNotes) * 100)}% of your notes` : 'No favorites yet',
      icon: Star,
      color: '#F59E0B',
      bg: '#FEF3C7',
    },
    {
      title: 'Recently Updated',
      value: mostRecent ? formatRelativeTime(mostRecent.updatedAt) : 'None',
      subtext: mostRecent ? mostRecent.title.slice(0, 24) + (mostRecent.title.length > 24 ? '...' : '') : 'Create your first note',
      icon: Clock,
      color: '#3B82F6',
      bg: '#EFF6FF',
    },
    {
      title: 'Words Captured',
      value: totalWords.toLocaleString(),
      subtext: 'Across all your thoughts',
      icon: Sparkles,
      color: '#10B981',
      bg: '#D1FAE5',
    },
  ];

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))',
        gap: '16px',
        marginBottom: '24px',
      }}
    >
      {statCards.map((stat, idx) => {
        const Icon = stat.icon;
        return (
          <div
            key={idx}
            className="card-clean"
            style={{
              padding: '16px 18px',
              display: 'flex',
              alignItems: 'center',
              gap: '14px',
            }}
          >
            <div
              style={{
                width: '46px',
                height: '46px',
                borderRadius: '12px',
                backgroundColor: stat.bg,
                color: stat.color,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0,
              }}
            >
              <Icon size={22} />
            </div>

            <div style={{ overflow: 'hidden' }}>
              <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontWeight: 600 }}>
                {stat.title}
              </div>
              <div
                style={{
                  fontSize: '1.35rem',
                  fontWeight: 800,
                  color: 'var(--text-main)',
                  letterSpacing: '-0.02em',
                  lineHeight: 1.2,
                  marginTop: '2px',
                }}
              >
                {stat.value}
              </div>
              <div
                style={{
                  fontSize: '0.72rem',
                  color: 'var(--text-light)',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  marginTop: '2px',
                }}
              >
                {stat.subtext}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
