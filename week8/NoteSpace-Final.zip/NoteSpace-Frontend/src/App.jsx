import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { DashboardPage } from './pages/DashboardPage';
import { BookOpen } from 'lucide-react';

const MainRouter = () => {
  const { isAuthenticated, isLoading } = useAuth();
  const [authView, setAuthView] = useState('landing'); // 'landing' | 'login' | 'register'

  if (isLoading) {
    return (
      <div
        className="bg-ambient-glow"
        style={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '16px',
        }}
      >
        <div
          style={{
            width: '54px',
            height: '54px',
            borderRadius: '16px',
            background: 'linear-gradient(135deg, #7C3AED 0%, #6D28D9 100%)',
            color: '#FFFFFF',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: 'var(--shadow-purple)',
            animation: 'pulseGlow 1.8s infinite ease-in-out',
          }}
        >
          <BookOpen size={26} strokeWidth={2.4} />
        </div>
        <div style={{ fontSize: '0.94rem', fontWeight: 600, color: 'var(--text-muted)' }}>
          Loading your NoteSpace...
        </div>
      </div>
    );
  }

  // Protected route logic: if authenticated, render Dashboard
  if (isAuthenticated) {
    return <DashboardPage />;
  }

  // Unauthenticated routing:
  if (authView === 'login') {
    return (
      <LoginPage
        onNavigateToRegister={() => setAuthView('register')}
        onNavigateToHome={() => setAuthView('landing')}
      />
    );
  }

  if (authView === 'register') {
    return (
      <RegisterPage
        onNavigateToLogin={() => setAuthView('login')}
        onNavigateToHome={() => setAuthView('landing')}
      />
    );
  }

  // Default: Landing Hero matching the user's reference design
  return (
    <LandingPage
      onNavigateToLogin={() => setAuthView('login')}
      onNavigateToRegister={() => setAuthView('register')}
    />
  );
};

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <MainRouter />
      </AuthProvider>
    </ToastProvider>
  );
}
