import React from 'react';
import { BookOpen, ArrowRight, Star } from 'lucide-react';

export const LandingPage = ({ onNavigateToLogin, onNavigateToRegister }) => {
  return (
    <div className="bg-ambient-glow" style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Top Navbar */}
      <header
        style={{
          height: '74px',
          padding: '0 36px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderBottom: '1px solid var(--border)',
          backgroundColor: 'rgba(255, 255, 255, 0.85)',
          backdropFilter: 'blur(12px)',
          position: 'sticky',
          top: 0,
          zIndex: 40,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div
            style={{
              width: '36px',
              height: '36px',
              borderRadius: '10px',
              background: 'linear-gradient(135deg, #7C3AED 0%, #6D28D9 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#FFFFFF',
              boxShadow: '0 6px 14px rgba(124, 58, 237, 0.25)',
            }}
          >
            <BookOpen size={19} strokeWidth={2.4} />
          </div>
          <span style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-main)', letterSpacing: '-0.025em' }}>
            NoteSpace
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <button
            onClick={onNavigateToLogin}
            className="btn-primary"
            style={{
              padding: '9px 18px',
              fontSize: '0.88rem',
              borderRadius: '10px',
            }}
          >
            Go to Dashboard
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <main style={{ flex: 1, padding: '64px 20px 80px', maxWidth: '1180px', margin: '0 auto', width: '100%' }}>
        <div style={{ textAlign: 'center', maxWidth: '820px', margin: '0 auto 48px' }}>
          {/* Top Pill Badge */}
          <div style={{ marginBottom: '22px' }}>
            <span className="pill-badge animate-fade-in">
              <span style={{ fontSize: '0.9rem' }}>★</span>
              <span>Beautifully designed for thinkers</span>
            </span>
          </div>

          {/* Main Headline */}
          <h1
            style={{
              fontSize: 'clamp(2.5rem, 5.5vw, 4.2rem)',
              fontWeight: 800,
              lineHeight: 1.15,
              letterSpacing: '-0.03em',
              color: 'var(--text-main)',
              marginBottom: '20px',
            }}
          >
            Your Thoughts.{' '}
            <span className="gradient-heading">Organized</span>
            <br />
            Beautifully.
          </h1>

          {/* Subtitle */}
          <p
            style={{
              fontSize: 'clamp(1rem, 2vw, 1.15rem)',
              color: 'var(--text-muted)',
              lineHeight: 1.6,
              maxWidth: '640px',
              margin: '0 auto 32px',
            }}
          >
            NoteSpace is a modern, secure note-taking application. Capture ideas, organize thoughts, and access your notes from anywhere — instantly.
          </p>

          {/* Call-to-Action Buttons */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '20px',
              flexWrap: 'wrap',
            }}
          >
            <button
              onClick={onNavigateToRegister}
              className="btn-primary"
              style={{
                padding: '13px 28px',
                fontSize: '1rem',
                borderRadius: '12px',
              }}
            >
              <span>Get Started Free</span>
              <ArrowRight size={18} />
            </button>

            <button
              onClick={onNavigateToLogin}
              style={{
                fontSize: '0.94rem',
                fontWeight: 600,
                color: 'var(--text-main)',
                textDecoration: 'underline',
                textUnderlineOffset: '4px',
                padding: '8px 12px',
              }}
            >
              Already have an account? Log in
            </button>
          </div>
        </div>

        {/* Dashboard Preview in Mac Window Mockup Frame */}
        <div className="mac-window animate-slide-down" style={{ marginTop: '36px' }}>
          <div className="mac-titlebar">
            <div className="mac-dot red" />
            <div className="mac-dot yellow" />
            <div className="mac-dot green" />
            <div className="mac-url">notespace.app/dashboard</div>
          </div>

          {/* Inner Dashboard Mock UI */}
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: '240px 1fr',
              minHeight: '440px',
              backgroundColor: '#FFFFFF',
            }}
            className="preview-grid"
          >
            {/* Mock Sidebar */}
            <div
              style={{
                borderRight: '1px solid var(--border)',
                padding: '24px 18px',
                display: 'flex',
                flexDirection: 'column',
                gap: '8px',
                backgroundColor: '#FAF9FE',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '18px' }}>
                <div
                  style={{
                    width: '28px',
                    height: '28px',
                    borderRadius: '8px',
                    background: 'linear-gradient(135deg, #7C3AED 0%, #6D28D9 100%)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#FFFFFF',
                  }}
                >
                  <BookOpen size={14} />
                </div>
                <span style={{ fontWeight: 800, fontSize: '0.95rem', color: 'var(--text-main)' }}>
                  NoteSpace
                </span>
              </div>

              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  padding: '9px 12px',
                  borderRadius: '10px',
                  backgroundColor: '#F3EEFF',
                  color: '#7C3AED',
                  fontWeight: 700,
                  fontSize: '0.85rem',
                }}
              >
                <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#7C3AED' }} />
                <span>Dashboard</span>
              </div>

              {['All Notes', 'Recent', 'Favorites', 'Profile'].map((item, i) => (
                <div
                  key={i}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    padding: '8px 12px',
                    borderRadius: '10px',
                    color: 'var(--text-muted)',
                    fontSize: '0.85rem',
                    fontWeight: 500,
                  }}
                >
                  <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: 'transparent', border: '1.5px solid var(--text-light)' }} />
                  <span>{item}</span>
                </div>
              ))}
            </div>

            {/* Mock Main Dashboard Canvas */}
            <div style={{ padding: '28px', backgroundColor: '#FCFBFF' }}>
              {/* Stat Cards Row */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px', marginBottom: '22px' }}>
                <div
                  style={{
                    padding: '16px',
                    backgroundColor: '#FFFFFF',
                    border: '1px solid var(--border)',
                    borderRadius: '12px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '4px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#7C3AED' }} />
                    <span style={{ fontWeight: 700, fontSize: '0.95rem', color: 'var(--text-main)' }}>12 Notes</span>
                  </div>
                  <span style={{ fontSize: '0.74rem', color: 'var(--text-muted)', paddingLeft: '16px' }}>Active notes saved</span>
                </div>

                <div
                  style={{
                    padding: '16px',
                    backgroundColor: '#FFFFFF',
                    border: '1px solid var(--border)',
                    borderRadius: '12px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '4px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#10B981' }} />
                    <span style={{ fontWeight: 700, fontSize: '0.95rem', color: 'var(--text-main)' }}>3 Updated Today</span>
                  </div>
                  <span style={{ fontSize: '0.74rem', color: 'var(--text-muted)', paddingLeft: '16px' }}>Sync completed</span>
                </div>

                <div
                  style={{
                    padding: '16px',
                    backgroundColor: '#FFFFFF',
                    border: '1px solid var(--border)',
                    borderRadius: '12px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '4px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#06B6D4' }} />
                    <span style={{ fontWeight: 700, fontSize: '0.95rem', color: 'var(--text-main)' }}>All Synced</span>
                  </div>
                  <span style={{ fontSize: '0.74rem', color: 'var(--text-muted)', paddingLeft: '16px' }}>MongoDB Atlas</span>
                </div>
              </div>

              {/* Mock Note Cards Row */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '14px' }}>
                <div
                  style={{
                    padding: '18px',
                    backgroundColor: '#FFFFFF',
                    border: '1px solid var(--border)',
                    borderRadius: '14px',
                    borderLeft: '4px solid #7C3AED',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                    <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#7C3AED' }} />
                    <span style={{ fontWeight: 700, fontSize: '0.94rem', color: 'var(--text-main)' }}>Learning React</span>
                  </div>
                  <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5, margin: 0 }}>
                    Component composition, hooks architecture, and state management patterns.
                  </p>
                </div>

                <div
                  style={{
                    padding: '18px',
                    backgroundColor: '#FFFFFF',
                    border: '1px solid var(--border)',
                    borderRadius: '14px',
                    borderLeft: '4px solid #06B6D4',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                    <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#06B6D4' }} />
                    <span style={{ fontWeight: 700, fontSize: '0.94rem', color: 'var(--text-main)' }}>Project Ideas</span>
                  </div>
                  <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5, margin: 0 }}>
                    Modern minimalist productivity app with soft lavender gradients and lots of whitespace.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
